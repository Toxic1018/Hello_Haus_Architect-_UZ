import * as vscode from 'vscode';
import { spawn } from 'child_process';
import * as path from 'path';

let diagnosticCollection: vscode.DiagnosticCollection;
let outputChannel: vscode.OutputChannel;

export function activate(context: vscode.ExtensionContext) {
	diagnosticCollection = vscode.languages.createDiagnosticCollection('pyguard');
	outputChannel = vscode.window.createOutputChannel('PyGuard');
	context.subscriptions.push(diagnosticCollection, outputChannel);

	// Buyruqlarni ro'yxatdan o'tkazish
	context.subscriptions.push(
		vscode.commands.registerCommand('pyguard.analyzeFile', () => analyzeActiveFile()),
		vscode.commands.registerCommand('pyguard.fixFile', () => fixActiveFile()),
		vscode.commands.registerCommand('pyguard.checkMemory', () => checkMemoryActiveFile())
	);

	// Fayl saqlanganda avtomatik ishga tushirish
	context.subscriptions.push(
		vscode.workspace.onDidSaveTextDocument((doc) => {
			const runOnSave = vscode.workspace.getConfiguration('pyguard').get<boolean>('runOnSave');
			if (runOnSave && doc.languageId === 'python') {
				analyzeDocument(doc);
			}
		})
	);

	// Quick Fix taklif qiluvchi provider
	context.subscriptions.push(
		vscode.languages.registerCodeActionsProvider('python', new PyGuardCodeActionProvider())
	);
}

function getPythonPath(): string {
	return vscode.workspace.getConfiguration('pyguard').get<string>('pythonPath') || 'python3';
}

function getBackendScript(scriptName: string): string {
	return path.join(__dirname, '..', 'python_backend', scriptName);
}

function runPythonScript(scriptName: string, filePath: string): Promise<any> {
	return new Promise((resolve, reject) => {
		const pythonPath = getPythonPath();
		const scriptPath = getBackendScript(scriptName);
		const proc = spawn(pythonPath, [scriptPath, filePath]);

		let stdout = '';
		let stderr = '';

		proc.stdout.on('data', (data) => (stdout += data.toString()));
		proc.stderr.on('data', (data) => (stderr += data.toString()));

		proc.on('close', (code) => {
			if (stderr) {
				outputChannel.appendLine(`[PyGuard xato]: ${stderr}`);
			}
			try {
				resolve(JSON.parse(stdout));
			} catch (e) {
				reject(`JSON tahlil qilishda xato: ${stdout}`);
			}
		});
	});
}

async function analyzeDocument(doc: vscode.TextDocument) {
	if (doc.languageId !== 'python') {
		return;
	}
	try {
		const result = await runPythonScript('analyzer.py', doc.fileName);
		const diagnostics: vscode.Diagnostic[] = [];

		for (const issue of result.issues || []) {
			const line = Math.max(0, (issue.line || 1) - 1);
			const range = new vscode.Range(line, 0, line, 200);
			const severity =
				issue.severity === 'error'
					? vscode.DiagnosticSeverity.Error
					: issue.severity === 'warning'
					? vscode.DiagnosticSeverity.Warning
					: vscode.DiagnosticSeverity.Information;

			const diagnostic = new vscode.Diagnostic(range, issue.message, severity);
			diagnostic.code = issue.code || '';
			diagnostic.source = 'PyGuard';
			diagnostics.push(diagnostic);
		}

		diagnosticCollection.set(doc.uri, diagnostics);
	} catch (e) {
		outputChannel.appendLine(`Tahlil xatosi: ${e}`);
	}
}

async function analyzeActiveFile() {
	const editor = vscode.window.activeTextEditor;
	if (!editor) {
		vscode.window.showWarningMessage('Faol Python fayli topilmadi.');
		return;
	}
	vscode.window.withProgress(
		{ location: vscode.ProgressLocation.Notification, title: 'PyGuard: kod tahlil qilinmoqda...' },
		async () => {
			await analyzeDocument(editor.document);
			vscode.window.showInformationMessage('PyGuard: tahlil tugadi. Muammolar panelini tekshiring.');
		}
	);
}

async function fixActiveFile() {
	const editor = vscode.window.activeTextEditor;
	if (!editor) {
		vscode.window.showWarningMessage('Faol Python fayli topilmadi.');
		return;
	}
	const filePath = editor.document.fileName;
	await editor.document.save();

	vscode.window.withProgress(
		{ location: vscode.ProgressLocation.Notification, title: 'PyGuard: xatolar tuzatilmoqda...' },
		async () => {
			try {
				const result = await runPythonScript('fixer.py', filePath);
				if (result.fixed) {
					// Faylni qayta yuklash (Python skript uni diskda tuzatgan)
					const doc = await vscode.workspace.openTextDocument(filePath);
					await vscode.window.showTextDocument(doc);
					vscode.window.showInformationMessage(
						`PyGuard: ${result.changes_count || 0} ta o'zgarish qo'llandi.`
					);
					await analyzeDocument(doc);
				} else {
					vscode.window.showInformationMessage('PyGuard: tuzatish uchun hech narsa topilmadi.');
				}
			} catch (e) {
				vscode.window.showErrorMessage(`PyGuard tuzatish xatosi: ${e}`);
			}
		}
	);
}

async function checkMemoryActiveFile() {
	const editor = vscode.window.activeTextEditor;
	if (!editor) {
		vscode.window.showWarningMessage('Faol Python fayli topilmadi.');
		return;
	}
	vscode.window.withProgress(
		{ location: vscode.ProgressLocation.Notification, title: 'PyGuard: xotira tahlil qilinmoqda...' },
		async () => {
			try {
				const result = await runPythonScript('memory_check.py', editor.document.fileName);
				outputChannel.clear();
				outputChannel.appendLine('=== PyGuard Xotira Tahlili ===');
				outputChannel.appendLine(`Umumiy joriy xotira: ${result.current_kb} KB`);
				outputChannel.appendLine(`Eng ko'p xotira: ${result.peak_kb} KB`);
				outputChannel.appendLine('');
				outputChannel.appendLine('Tavsiyalar:');
				for (const tip of result.suggestions || []) {
					outputChannel.appendLine(`  - Qator ${tip.line}: ${tip.message}`);
				}
				outputChannel.show();
			} catch (e) {
				vscode.window.showErrorMessage(`PyGuard xotira tahlili xatosi: ${e}`);
			}
		}
	);
}

class PyGuardCodeActionProvider implements vscode.CodeActionProvider {
	provideCodeActions(
		document: vscode.TextDocument,
		range: vscode.Range | vscode.Selection,
		context: vscode.CodeActionContext
	): vscode.CodeAction[] {
		const actions: vscode.CodeAction[] = [];
		const pyguardDiagnostics = context.diagnostics.filter((d) => d.source === 'PyGuard');

		if (pyguardDiagnostics.length > 0) {
			const fixAction = new vscode.CodeAction(
				"PyGuard: Avtomatik tuzatish",
				vscode.CodeActionKind.QuickFix
			);
			fixAction.command = {
				command: 'pyguard.fixFile',
				title: "PyGuard: Avtomatik tuzatish"
			};
			fixAction.diagnostics = pyguardDiagnostics;
			actions.push(fixAction);
		}

		return actions;
	}
}

export function deactivate() {}
