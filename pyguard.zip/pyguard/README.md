# PyGuard — Python Error & Memory Checker (VS Code plagini)

Python kodidagi xatolarni topadi, ularni avtomatik tuzatadi va xotira
sarfini kamaytirish bo'yicha tavsiyalar beradi.

## Loyiha tuzilishi

```
pyguard/
├── src/
│   └── extension.ts        # VS Code bilan aloqa (TypeScript)
├── python_backend/
│   ├── analyzer.py         # Xatolarni topish
│   ├── fixer.py             # Avtomatik tuzatish
│   ├── memory_check.py      # Xotira tahlili
│   └── requirements.txt
├── .vscode/
│   └── launch.json          # F5 orqali test qilish sozlamasi
├── package.json
└── tsconfig.json
```

## O'rnatish (birinchi marta)

1. **Node.js** o'rnatilganligiga ishonch hosil qiling (v18+): https://nodejs.org

2. Loyiha papkasida terminal oching va bog'liqliklarni o'rnating:
   ```bash
   npm install
   ```

3. Python bog'liqliklarini o'rnating:
   ```bash
   pip install -r python_backend/requirements.txt
   ```

4. TypeScript kodini kompilyatsiya qiling:
   ```bash
   npm run compile
   ```

## Ishga tushirish va test qilish

1. Loyihani VS Code'da oching
2. `F5` tugmasini bosing — bu yangi "Extension Development Host" oynasini ochadi
3. Ochilgan yangi oynada istalgan `.py` faylni oching
4. Buyruqlar palitrasini oching (`Ctrl+Shift+P` / `Cmd+Shift+P`) va quyidagilardan birini tanlang:
   - `PyGuard: Kodni tahlil qilish`
   - `PyGuard: Xatolarni avtomatik tuzatish`
   - `PyGuard: Xotira sarfini tekshirish`

Yoki Python faylini saqlaganingizda (`Ctrl+S`) avtomatik tahlil ishga tushadi
(buni `pyguard.runOnSave` sozlamasidan o'chirish mumkin).

## Sozlamalar

VS Code sozlamalarida (`settings.json`) quyidagilarni o'zgartirish mumkin:

```json
{
  "pyguard.pythonPath": "python3",
  "pyguard.runOnSave": true
}
```

Agar virtual muhit (venv) ishlatsangiz, `pyguard.pythonPath`ni
venv ichidagi python yo'liga o'zgartiring, masalan:
`"./venv/bin/python"` (Mac/Linux) yoki `".\\venv\\Scripts\\python.exe"` (Windows).

## Qanday ishlaydi

1. `extension.ts` — `child_process.spawn()` orqali Python skriptlarini chaqiradi
2. Python skriptlar (`analyzer.py`, `fixer.py`, `memory_check.py`) natijani
   **JSON** formatda qaytaradi
3. TypeScript tomon bu natijalarni VS Code'ning **Diagnostics API**si orqali
   qizil/sariq chiziqlar va "Quick Fix" (💡) tugmalari sifatida ko'rsatadi

## Kengaytirish g'oyalari

- `analyzer.py` ga yangi tekshiruv qoidalari qo'shish (masalan: uzun funksiyalar,
  chuqur ichma-ich shartlar, dublikat kod)
- Murakkab xatolar uchun Claude API orqali AI tahlil qo'shish
- Xotira tahlilini kengaytirish: `memory_profiler` yordamida qatorma-qator
  xotira sarfini o'lchash
- Natijalarni cache'lash — katta fayllar uchun tezlikni oshirish

## Nashr qilish (ixtiyoriy)

Plaginni VS Code Marketplace'ga chiqarish uchun `vsce` vositasidan foydalaning:

```bash
npm install -g @vscode/vsce
vsce package
```

Bu `.vsix` fayl yaratadi — uni boshqalarga ulashish yoki
`code --install-extension pyguard-0.0.1.vsix` orqali o'rnatish mumkin.
