"""PyGuard'ni sinash uchun ataylab xatolar bilan yozilgan fayl."""


def add_item(item, my_list=[]):  # mutable default argument
    my_list.append(item)
    return my_list


def risky_function():
    try:
        result = 10 / 0
    except:  # bare except
        result = None
    return result


class Point:  # __slots__ yo'q
    def __init__(self, x, y):
        self.x = x
        self.y = y


def process_data():
    unused_variable = 42  # ishlatilmagan o'zgaruvchi
    total = sum([i * i for i in range(1000)])  # generator o'rniga list
    return total
