"""
PyGuard Memory Checker
----------------------
Python faylini xotira sarfi nuqtai nazaridan tahlil qiladi:
  1. tracemalloc yordamida faylni ishga tushirib, real xotira sarfini o'lchaydi
  2. Statik tahlil orqali xotira ko'p yeydigan naqshlarni topadi
     (masalan: list comprehension o'rniga generator, katta fayllarni
     to'liq o'qish, __slots__ ishlatmaslik va h.k.)

Ishlatilishi:
    python memory_check.py <fayl_yoli>

DIQQAT: Bu skript faylni HAQIQATDA ishga tushiradi (exec orqali),
shuning uchun faqat ishonchli kodlarga nisbatan ishlatilishi kerak.
"""

import ast
import sys
import json
import tracemalloc
import runpy


def find_memory_patterns(tree: ast.AST):
    """Xotirani ko'p yeydigan keng tarqalgan naqshlarni statik tarzda topadi."""
    suggestions = []

    for node in ast.walk(tree):
        # list comprehension o'rniga generator ishlatish mumkin bo'lgan holatlar
        # (masalan sum([...]) yoki any([...]) ichida)
        if isinstance(node, ast.Call):
            func_name = getattr(node.func, "id", None)
            if func_name in ("sum", "any", "all", "max", "min") and node.args:
                arg = node.args[0]
                if isinstance(arg, ast.ListComp):
                    suggestions.append({
                        "line": node.lineno,
                        "message": f"'{func_name}()' ichida list comprehension o'rniga generator "
                                   f"ishlating: {func_name}(x for x in ...) — bu butun ro'yxatni "
                                   f"xotirada saqlashning oldini oladi",
                    })

        # .read() bilan butun faylni xotiraga yuklash
        if isinstance(node, ast.Call):
            attr = node.func
            if isinstance(attr, ast.Attribute) and attr.attr == "read":
                suggestions.append({
                    "line": node.lineno,
                    "message": "'.read()' butun faylni xotiraga yuklaydi — katta fayllar uchun "
                               "qatorma-qator o'qish (for line in file) yoki .read(chunk_size) "
                               "dan foydalaning",
                })

        # class'larda __slots__ yo'qligini tekshirish
        if isinstance(node, ast.ClassDef):
            has_slots = any(
                isinstance(stmt, ast.Assign) and
                any(isinstance(t, ast.Name) and t.id == "__slots__" for t in stmt.targets)
                for stmt in node.body
            )
            if not has_slots:
                suggestions.append({
                    "line": node.lineno,
                    "message": f"'{node.name}' klassida '__slots__' aniqlanmagan — ko'p nusxada "
                               f"yaratiladigan klasslar uchun bu xotirani sezilarli tejaydi",
                })

    return suggestions


def measure_runtime_memory(filepath: str):
    """Faylni ishga tushirib, haqiqiy xotira sarfini o'lchaydi."""
    tracemalloc.start()
    try:
        runpy.run_path(filepath, run_name="__main__")
    except Exception:
        # Fayl xato bilan tugasa ham, shu paytgacha bo'lgan xotira o'lchovini olamiz
        pass
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return current, peak


def check(filepath: str) -> dict:
    with open(filepath, "r", encoding="utf-8") as f:
        code = f.read()

    tree = ast.parse(code)
    suggestions = find_memory_patterns(tree)

    try:
        current, peak = measure_runtime_memory(filepath)
    except Exception:
        current, peak = 0, 0

    return {
        "current_kb": round(current / 1024, 2),
        "peak_kb": round(peak / 1024, 2),
        "suggestions": suggestions,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"current_kb": 0, "peak_kb": 0, "suggestions": [], "error": "Fayl yo'li berilmagan"}))
        sys.exit(1)

    try:
        output = check(sys.argv[1])
    except Exception as exc:
        output = {"current_kb": 0, "peak_kb": 0, "suggestions": [], "error": str(exc)}

    print(json.dumps(output, ensure_ascii=False))
