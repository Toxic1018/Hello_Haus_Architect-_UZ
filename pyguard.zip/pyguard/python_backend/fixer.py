"""
PyGuard Fixer
-------------
Python faylidagi oddiy xatolarni avtomatik tuzatadi:
  - Formatlash (black yoki autopep8 orqali)
  - Ishlatilmagan import'larni olib tashlash (autoflake orqali)

Ishlatilishi:
    python fixer.py <fayl_yoli>
"""

import sys
import json
import subprocess


def try_autoflake(filepath: str) -> bool:
    """Ishlatilmagan import va o'zgaruvchilarni olib tashlaydi."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "autoflake", "--in-place",
             "--remove-unused-variables", "--remove-all-unused-imports", filepath],
            capture_output=True, text=True, timeout=20
        )
        return result.returncode == 0
    except FileNotFoundError:
        return False
    except subprocess.TimeoutExpired:
        return False


def try_black(filepath: str) -> bool:
    """Kodni black formatiga soladi."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "black", "--quiet", filepath],
            capture_output=True, text=True, timeout=20
        )
        return result.returncode == 0
    except FileNotFoundError:
        return False
    except subprocess.TimeoutExpired:
        return False


def try_autopep8(filepath: str) -> bool:
    """black topilmasa, autopep8 bilan formatlaydi (zaxira variant)."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "autopep8", "--in-place", "--aggressive", filepath],
            capture_output=True, text=True, timeout=20
        )
        return result.returncode == 0
    except FileNotFoundError:
        return False
    except subprocess.TimeoutExpired:
        return False


def fix(filepath: str) -> dict:
    with open(filepath, "r", encoding="utf-8") as f:
        original = f.read()

    changes = 0
    if try_autoflake(filepath):
        changes += 1
    if not try_black(filepath):
        if try_autopep8(filepath):
            changes += 1
    else:
        changes += 1

    with open(filepath, "r", encoding="utf-8") as f:
        new_content = f.read()

    return {
        "fixed": new_content != original,
        "changes_count": changes,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"fixed": False, "error": "Fayl yo'li berilmagan"}))
        sys.exit(1)

    try:
        output = fix(sys.argv[1])
    except Exception as exc:
        output = {"fixed": False, "error": str(exc)}

    print(json.dumps(output, ensure_ascii=False))
