"""
PyGuard Analyzer
----------------
Python faylini tahlil qiladi: sintaksis xatolari, ishlatilmagan
o'zgaruvchilar, import muammolari va boshqa keng tarqalgan
xatolarni topadi. Natijani JSON formatda stdout'ga chiqaradi.

Ishlatilishi:
    python analyzer.py <fayl_yoli>
"""

import ast
import sys
import json
import subprocess


def get_syntax_error(code: str):
    """Sintaksis xatosini tekshiradi."""
    try:
        ast.parse(code)
        return None
    except SyntaxError as e:
        return {
            "line": e.lineno or 1,
            "message": f"Sintaksis xatosi: {e.msg}",
            "severity": "error",
            "code": "syntax-error",
        }


def find_unused_variables(tree: ast.AST):
    """Oddiy statik tahlil orqali ishlatilmagan o'zgaruvchilarni topadi."""
    issues = []

    class UnusedVarVisitor(ast.NodeVisitor):
        def __init__(self):
            self.assigned = {}
            self.used = set()

        def visit_Name(self, node):
            if isinstance(node.ctx, ast.Store):
                self.assigned[node.id] = node.lineno
            elif isinstance(node.ctx, ast.Load):
                self.used.add(node.id)
            self.generic_visit(node)

    visitor = UnusedVarVisitor()
    visitor.visit(tree)

    for name, lineno in visitor.assigned.items():
        if name not in visitor.used and not name.startswith("_"):
            issues.append({
                "line": lineno,
                "message": f"'{name}' o'zgaruvchisi e'lon qilingan, lekin ishlatilmagan",
                "severity": "warning",
                "code": "unused-variable",
            })
    return issues


def find_bare_except(tree: ast.AST):
    """Yalang'och 'except:' bloklarini topadi (yomon amaliyot)."""
    issues = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler) and node.type is None:
            issues.append({
                "line": node.lineno,
                "message": "Yalang'och 'except:' ishlatilgan — aniq xato turini ko'rsating (masalan 'except ValueError:')",
                "severity": "warning",
                "code": "bare-except",
            })
    return issues


def find_mutable_default_args(tree: ast.AST):
    """Funksiya argumentlarida o'zgaruvchan default qiymatlarni topadi (list, dict)."""
    issues = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for default in node.args.defaults:
                if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                    issues.append({
                        "line": node.lineno,
                        "message": f"'{node.name}' funksiyasida o'zgaruvchan default qiymat ishlatilgan — bu kutilmagan xatoliklarga olib kelishi mumkin",
                        "severity": "warning",
                        "code": "mutable-default-arg",
                    })
    return issues


def run_pyflakes(filepath: str):
    """Agar pyflakes o'rnatilgan bo'lsa, undan qo'shimcha tahlil uchun foydalanadi."""
    issues = []
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pyflakes", filepath],
            capture_output=True, text=True, timeout=15
        )
        for line in result.stdout.splitlines():
            parts = line.split(":", 3)
            if len(parts) >= 4:
                try:
                    lineno = int(parts[1])
                except ValueError:
                    continue
                issues.append({
                    "line": lineno,
                    "message": parts[3].strip(),
                    "severity": "warning",
                    "code": "pyflakes",
                })
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return issues


def analyze(filepath: str):
    with open(filepath, "r", encoding="utf-8") as f:
        code = f.read()

    syntax_error = get_syntax_error(code)
    if syntax_error:
        return {"issues": [syntax_error]}

    tree = ast.parse(code)
    issues = []
    issues.extend(find_unused_variables(tree))
    issues.extend(find_bare_except(tree))
    issues.extend(find_mutable_default_args(tree))
    issues.extend(run_pyflakes(filepath))

    return {"issues": issues}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"issues": [], "error": "Fayl yo'li berilmagan"}))
        sys.exit(1)

    try:
        output = analyze(sys.argv[1])
    except Exception as exc:
        output = {"issues": [], "error": str(exc)}

    print(json.dumps(output, ensure_ascii=False))
